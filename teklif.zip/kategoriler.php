<?php
include 'db.php';

// Kategori ekleme işlemi
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['kategori_adi'])) {
    $kategori_adi = $_POST['kategori_adi'];
    $stmt = $pdo->prepare("INSERT INTO categories (name) VALUES (?)");
    $stmt->execute([$kategori_adi]);
    header("Location: index.php?sayfa=kategoriler");
    exit();
}

// Kategori silme işlemi
if (isset($_GET['sil'])) {
    $id = $_GET['sil'];
    $stmt = $pdo->prepare("DELETE FROM categories WHERE id = ?");
    $stmt->execute([$id]);
    header("Location: index.php?sayfa=kategoriler");
    exit();
}

// Kategorileri çekme
$stmt = $pdo->query("SELECT * FROM categories ORDER BY id DESC");
$kategoriler = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<h2>Kategoriler</h2>

<form method="post">
    <input type="text" name="kategori_adi" placeholder="Yeni kategori adı" required>
    <button type="submit">Kategori Ekle</button>
</form>

<table border="1" cellpadding="8" cellspacing="0" style="margin-top:20px;">
    <tr>
        <th>ID</th>
        <th>Kategori Adı</th>
        <th>Aksiyon</th>
    </tr>
    <?php foreach ($kategoriler as $kategori): ?>
        <tr>
            <td><?= $kategori['id'] ?></td>
            <td><?= htmlspecialchars($kategori['name']) ?></td>
            <td><a href="?sayfa=kategoriler&sil=<?= $kategori['id'] ?>" onclick="return confirm('Silmek istediğinize emin misiniz?')">Sil</a></td>
        </tr>
    <?php endforeach; ?>
</table>
