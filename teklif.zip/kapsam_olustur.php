<?php
require_once 'db.php';

$scopeId = isset($_GET['id']) ? intval($_GET['id']) : 0;
$scopeName = '';
$selectedItems = [];

// Mevcut kapsam bilgisi çekiliyor
if ($scopeId > 0) {
    $stmt = $pdo->prepare("SELECT * FROM scopes WHERE id = ?");
    $stmt->execute([$scopeId]);
    $scope = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($scope) {
        $scopeName = $scope['name'];
    }

    // Bu kapsama ait seçili kalemler
    $stmt = $pdo->prepare("SELECT * FROM scope_selections WHERE scope_id = ?");
    $stmt->execute([$scopeId]);
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $selectedItems[$row['item_id']] = [
            'adet' => $row['adet'],
        ];
    }
}

// Tüm kategori ve iş kalemleri çekiliyor
$categories = $pdo->query("SELECT * FROM categories")->fetchAll(PDO::FETCH_ASSOC);
$itemsByCategory = [];

foreach ($categories as $category) {
    $stmt = $pdo->prepare("SELECT * FROM items WHERE category_id = ?");
    $stmt->execute([$category['id']]);
    $itemsByCategory[$category['id']] = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Kapsam Oluştur</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .edit-row input {
            width: 100%;
        }
        td {
            vertical-align: middle;
        }
    </style>
</head>
<body>
    <h2><?php echo $scopeId > 0 ? "Kapsam Düzenle" : "Yeni Kapsam Oluştur"; ?></h2>

    <form action="kapsam_kaydet.php" method="post">
        <?php if ($scopeId > 0): ?>
            <input type="hidden" name="scope_id" value="<?php echo $scopeId; ?>">
        <?php endif; ?>

        <label>Kapsam Adı:</label>
        <input type="text" name="scope_name" required value="<?php echo htmlspecialchars($scopeName); ?>">

        <table border="1" cellpadding="8" cellspacing="0">
            <tr>
                <th>Kategori</th>
                <th>İş Kalemi</th>
                <th>Açıklama</th>
                <th>Dahil mi?</th>
                <th>Adet / Yıl</th>
            </tr>

            <?php foreach ($categories as $category): ?>
                <?php foreach ($itemsByCategory[$category['id']] as $item): 
                    $itemId = $item['id'];
                    $selected = isset($selectedItems[$itemId]);
                    $adet = $selected ? $selectedItems[$itemId]['adet'] : '';
                ?>
                    <tr>
                        <td><?php echo htmlspecialchars($category['name']); ?></td>
                        <td><?php echo htmlspecialchars($item['name']); ?></td>
                        <td><?php echo htmlspecialchars($item['description']); ?></td>
                        <td style="text-align: center;">
                            <input type="checkbox" name="selected_items[]" value="<?php echo $itemId; ?>" <?php echo $selected ? 'checked' : ''; ?>>
                        </td>
                        <td style="text-align: center;">
                            <input type="number" name="adet[<?php echo $itemId; ?>]" value="<?php echo $adet; ?>" min="0">
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endforeach; ?>
        </table>

        <br>
        <button type="submit">Kaydet</button>
    </form>
</body>
</html>
