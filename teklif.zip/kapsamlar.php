<?php
include 'db.php';

// Kapsamları getir
$stmt = $pdo->query("SELECT * FROM scopes ORDER BY updated_at DESC");
$kapsamlar = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<h2>Kapsamlar</h2>

<div style="text-align:right; margin-bottom:10px;">
    <a href="kapsam_olustur.php" style="padding: 8px 12px; background-color:#4CAF50; color:white; text-decoration:none; border-radius:4px;">+ Kapsam Ekle</a>
</div>

<table border="1" cellpadding="8" cellspacing="0">
    <thead>
        <tr>
            <th>Kapsam</th>
            <th>Son Düzenleme Tarihi</th>
            <th>Aksiyonlar</th>
        </tr>
    </thead>
    <tbody>
        <?php if (count($kapsamlar) > 0): ?>
            <?php foreach ($kapsamlar as $kapsam): ?>
                <tr>
                    <td><?= htmlspecialchars($kapsam['name']) ?></td>
                    <td><?= date("d.m.Y H:i", strtotime($kapsam['updated_at'])) ?></td>
                    <td>
                        <a href="kapsam_olustur.php?id=<?= $kapsam['id'] ?>">Düzenle</a> |
                        <a href="kapsam_olustur.php?id=<?= $kapsam['id'] ?>" onclick="return confirm('Kapsamı silmek istediğinize emin misiniz?')">Sil</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr><td colspan="3">Henüz kapsam eklenmemiş.</td></tr>
        <?php endif; ?>
    </tbody>
</table>
