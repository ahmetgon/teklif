<?php
$page = $_GET['sayfa'] ?? 'kapsamlar';
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Yönetim Paneli</title>
    <link rel="stylesheet" href="style.css"> <!-- varsayılan stil -->
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
        }
        .sidebar {
            width: 200px;
            background: #2c3e50;
            height: 100vh;
            float: left;
            color: white;
        }
        .sidebar a {
            display: block;
            padding: 15px;
            color: white;
            text-decoration: none;
        }
        .sidebar a:hover,
        .sidebar a.active {
            background: #34495e;
        }
        .main {
            margin-left: 200px;
            padding: 20px;
        }
    </style>
</head>
<body>

<div class="sidebar">
    <a href="index.php?sayfa=kapsamlar" class="<?= $page == 'kapsamlar' ? 'active' : '' ?>">Kapsamlar</a>
    <a href="index.php?sayfa=kategoriler" class="<?= $page == 'kategoriler' ? 'active' : '' ?>">Kategoriler</a>
    <a href="index.php?sayfa=kalemler" class="<?= $page == 'kalemler' ? 'active' : '' ?>">İş Kalemleri</a>
</div>

<div class="main">
    <?php
    if ($page == 'kapsamlar') {
        include 'kapsamlar.php';
    } elseif ($page == 'kategoriler') {
        include 'kategoriler.php';
    } elseif ($page == 'kalemler') {
        include 'kalemler.php';
    } else {
        echo "<p>Geçersiz sayfa.</p>";
    }
    ?>
</div>

</body>
</html>
