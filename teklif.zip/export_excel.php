<?php
require 'vendor/autoload.php';
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Style\Alignment;

$conn = new mysqli("localhost", "root", "", "scope_db");

$kapsam_id = isset($_GET['kapsam_id']) ? (int)$_GET['kapsam_id'] : null;
if (!$kapsam_id) {
    die("Kapsam ID belirtilmedi.");
}

$res = $conn->query("SELECT * FROM kapsamlar WHERE id = $kapsam_id");
if (!$res || $res->num_rows === 0) {
    die("Kapsam bulunamadı.");
}
$kapsam = $res->fetch_assoc();

$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();

// === Stil ayarları ===
$styleHeader = [
    'font' => ['bold' => true],
    'fill' => [
        'fillType' => Fill::FILL_SOLID,
        'startColor' => ['rgb' => 'DDEBF7']
    ]
];
$styleCells = [
    'borders' => [
        'allBorders' => ['borderStyle' => Border::BORDER_THIN]
    ],
    'alignment' => [
        'wrapText' => true,
        'vertical' => Alignment::VERTICAL_CENTER
    ]
];
$styleQty = [
    'alignment' => [
        'horizontal' => Alignment::HORIZONTAL_CENTER,
        'vertical' => Alignment::VERTICAL_CENTER
    ]
];

// Sütun genişlikleri
$sheet->getColumnDimension('A')->setWidth(25);
$sheet->getColumnDimension('B')->setWidth(35);
$sheet->getColumnDimension('C')->setWidth(90);
$sheet->getColumnDimension('D')->setWidth(12);

// === Kapsama Dahil Olanlar ===
$row = 1;
$sheet->setCellValue("A{$row}", "Kapsam: " . $kapsam['baslik']);
$sheet->getStyle("A{$row}")->getFont()->setBold(true);
$row += 2;

$sheet->setCellValue("A{$row}", "Kapsama Dahil Olanlar");
$sheet->getStyle("A{$row}")->getFont()->setBold(true);
$row += 2;

$sheet->fromArray(['Kategori', 'İş Kalemi', 'Açıklama', 'Adet / Yıl'], NULL, "A{$row}");
$sheet->getStyle("A{$row}:D{$row}")->applyFromArray($styleHeader);
$row++;

$q = "
SELECT c.name as category_name, i.name as item_name, i.description, k.quantity
FROM kapsam_icerikleri k
JOIN items i ON k.item_id = i.id
JOIN categories c ON i.category_id = c.id
WHERE k.kapsam_id = $kapsam_id AND k.included = 1
ORDER BY c.name ASC
";
$res = $conn->query($q);
$start = $row;
while ($r = $res->fetch_assoc()) {
    $sheet->setCellValue("A{$row}", $r['category_name']);
    $sheet->setCellValue("B{$row}", $r['item_name']);
    $sheet->setCellValue("C{$row}", $r['description']);
    $sheet->setCellValue("D{$row}", $r['quantity']);
    $sheet->getStyle("D{$row}")->applyFromArray($styleQty);
    $row++;
}
$sheet->getStyle("A{$start}:D" . ($row - 1))->applyFromArray($styleCells);

// === Kapsama Dahil Olmayanlar ===
$row += 2;
$sheet->setCellValue("A{$row}", "Kapsama Dahil Olmayanlar");
$sheet->getStyle("A{$row}")->getFont()->setBold(true);
$row += 2;

$sheet->fromArray(['Kategori', 'İş Kalemi', 'Açıklama', 'Adet / Yıl'], NULL, "A{$row}");
$sheet->getStyle("A{$row}:D{$row}")->applyFromArray($styleHeader);
$row++;

$q = "
SELECT c.name as category_name, i.name as item_name, i.description, k.quantity
FROM kapsam_icerikleri k
JOIN items i ON k.item_id = i.id
JOIN categories c ON i.category_id = c.id
WHERE k.kapsam_id = $kapsam_id AND k.included = 0
ORDER BY c.name ASC
";
$res = $conn->query($q);
$start = $row;
while ($r = $res->fetch_assoc()) {
    $sheet->setCellValue("A{$row}", $r['category_name']);
    $sheet->setCellValue("B{$row}", $r['item_name']);
    $sheet->setCellValue("C{$row}", $r['description']);
    $sheet->setCellValue("D{$row}", $r['quantity']);
    $sheet->getStyle("D{$row}")->applyFromArray($styleQty);
    $row++;
}
$sheet->getStyle("A{$start}:D" . ($row - 1))->applyFromArray($styleCells);

// === İndir ===
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="kapsam_' . $kapsam_id . '.xlsx"');
header('Cache-Control: max-age=0');

$writer = new Xlsx($spreadsheet);
$writer->save('php://output');
exit;
