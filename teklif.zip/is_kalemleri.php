<?php
include 'db.php';

// İş kalemi ekleme
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['isim'], $_POST['kategori_id'], $_POST['aciklama'])) {
    $isim = $_POST['isim'];
    $kategori_id = $_POST['kategori_id'];
    $aciklama = $_POST['aciklama'];

    $stmt = $pdo->prepare("INSERT INTO items (category_id, name, description) VALUES (?, ?, ?)");
    $stmt->execute([$kategori_id, $isim, $aciklama]);
    header("Location: index.php?sayfa=is_kalemleri");
    exit();
}

// İş kalemi silme
if (isset($_GET['sil'])) {
    $id = $_GET['sil'];
    $stmt = $pdo->prepare("DELETE FROM items WHERE id = ?");
    $stmt->execute([$id]);
    header("Location: index.php?sayfa=is_kalemleri");
    exit();
}

// Kategorileri al
$stmt = $pdo->query("SELECT * FROM categories ORDER BY name ASC");
$kategoriler = $stmt->fetchAll(PDO::FETCH_ASSOC);

// İş kalemlerini al
$stmt = $pdo->query("SELECT items.*, categories.name AS kategori_adi FROM items JOIN categories ON items.category_id = categories.id ORDER BY items.id DESC");
$is_kalemleri = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<h2>İş Kalemleri</h2>

<form method="post">
    <select name="kategori_id" required>
        <option value="">Kategori Seçin</option>
        <?php foreach ($kategoriler as $kat): ?>
            <option value="<?= $kat['id'] ?>"><?= htmlspecialchars($kat['name']) ?></option>
        <?php endforeach; ?>
    </select>
    <input type="text" name="isim" placeholder="İş Kalemi Adı" required>
    <input type="text" name="aciklama" placeholder="Açıklama" required>
    <button type="submit">Ekle</button>
</form>

<table border="1" cellpadding="8" cellspacing="0" style="margin-top:20px;">
    <tr>
        <th>ID</th>
        <th>Kategori</th>
        <th>İş Kalemi Adı</th>
        <th>Açıklama</th>
        <th>Aksiyon</th>
    </tr>
    <?php foreach ($is_kalemleri as $kalem): ?>
        <tr>
            <td><?= $kalem['id'] ?></td>
            <td><?= htmlspecialchars($kalem['kategori_adi']) ?></td>
            <td><?= htmlspecialchars($kalem['name']) ?></td>
            <td><?= htmlspecialchars($kalem['description']) ?></td>
            <td><a href="?sayfa=is_kalemleri&sil=<?= $kalem['id'] ?>" onclick="return confirm('Silmek istediğinize emin misiniz?')">Sil</a></td>
        </tr>
    <?php endforeach; ?>
</table>
