<?php
require_once 'db.php';

if (isset($_GET['id'])) {
    $kapsam_id = intval($_GET['id']);

    // Önce bu kapsama ait kalemleri silelim
    $stmt_kalemler = $conn->prepare("DELETE FROM kapsam_kalemleri WHERE kapsam_id = ?");
    $stmt_kalemler->bind_param("i", $kapsam_id);
    $stmt_kalemler->execute();
    $stmt_kalemler->close();

    // Sonra kapsamın kendisini silelim
    $stmt = $conn->prepare("DELETE FROM kapsamlar WHERE id = ?");
    $stmt->bind_param("i", $kapsam_id);
    $stmt->execute();
    $stmt->close();
}

header("Location: index.php?sayfa=kapsamlar");
exit;
