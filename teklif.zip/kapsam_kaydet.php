<?php
require_once 'db.php';

$scopeId = isset($_POST['scope_id']) ? intval($_POST['scope_id']) : 0;
$scopeName = trim($_POST['scope_name']);
$selectedItems = isset($_POST['selected_items']) ? $_POST['selected_items'] : [];
$adetler = isset($_POST['adet']) ? $_POST['adet'] : [];

// Yeni kapsam mı, var olan mı?
if ($scopeId > 0) {
    // Güncelleme
    $stmt = $pdo->prepare("UPDATE scopes SET name = ?, updated_at = NOW() WHERE id = ?");
    $stmt->execute([$scopeName, $scopeId]);

    // Önceki seçimleri temizle
    $pdo->prepare("DELETE FROM scope_selections WHERE scope_id = ?")->execute([$scopeId]);
} else {
    // Yeni kapsam oluştur
    $stmt = $pdo->prepare("INSERT INTO scopes (name, created_at, updated_at) VALUES (?, NOW(), NOW())");
    $stmt->execute([$scopeName]);
    $scopeId = $pdo->lastInsertId();
}

// Yeni seçimleri kaydet
$insertStmt = $pdo->prepare("INSERT INTO scope_selections (scope_id, item_id, adet) VALUES (?, ?, ?)");

foreach ($selectedItems as $itemId) {
    $adet = isset($adetler[$itemId]) && is_numeric($adetler[$itemId]) ? intval($adetler[$itemId]) : 0;
    $insertStmt->execute([$scopeId, $itemId, $adet]);
}

header("Location: index.php");
exit;
